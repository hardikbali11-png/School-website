NEW MODERN HIGH SCHOOL PATRARA — WEBSITE PACKAGE

This is a ready-to-preview responsive website made from the school photos and logo supplied in the chat.

To preview:
1. Extract the ZIP.
2. Open index.html in Chrome.

Important:
- Replace the placeholder phone/email/WhatsApp details in index.html with the school's real details.
- This package is a website prototype; Google Sites does not directly import a complete HTML site as a normal page.
- For Google Sites, use the same sections/images/content manually, or publish this site on a web host and embed its URL in Google Sites.
